package weather;

import java.util.ArrayList;

public class Geometry2 {
    public String type;
    public ArrayList<Double> coordinates;

    }

