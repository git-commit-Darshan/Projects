package weather;

public class ProbabilityOfPrecipitation{
    public String unitCode;
    public int value;
}
