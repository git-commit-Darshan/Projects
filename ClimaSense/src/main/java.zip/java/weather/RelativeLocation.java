package weather;

public class RelativeLocation {
    public String type;
    public Geometry2 geometry;
    public Properties properties;
}
