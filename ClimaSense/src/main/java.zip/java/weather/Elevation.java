package weather;

public class Elevation{
    public String unitCode;
    public double value;
}
